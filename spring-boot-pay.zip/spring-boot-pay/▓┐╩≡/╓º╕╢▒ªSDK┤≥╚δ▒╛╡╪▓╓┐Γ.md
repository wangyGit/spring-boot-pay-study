SDK下载地址：https://pan.baidu.com/s/1B2_uyrz2uKN1Z_Ivbv7lgw

打入本地仓库：

```
mvn install:install-file -Dfile=alipay-trade-sdk-3.3.0.jar -DgroupId=vip.52itstyle -DartifactId=alipay-trade-sdk -Dversion=1.0.0 -Dpackaging=jar
```
